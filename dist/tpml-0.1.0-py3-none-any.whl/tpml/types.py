from numpy import np
NPArray = np.ndarray
