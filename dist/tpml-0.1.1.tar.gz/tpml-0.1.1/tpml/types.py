import numpy as np
NPArray = np.ndarray
